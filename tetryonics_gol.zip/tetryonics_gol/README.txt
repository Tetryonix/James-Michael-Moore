================================================================================
  TETRYONIC GAME OF LIFE — BUILD INSTRUCTIONS
  Visual Studio 2019 or 2022, Windows 64-bit
================================================================================

WHAT YOU'RE BUILDING
--------------------
A real-time cellular automaton on the A2 Eisenstein integer simplex lattice,
implementing Tetryonic Theory physics:

  2D layer:  ZPF quanta (equilateral triangles) — Game of Life, KEM gliders
             These are Lorentz VARIANT (KEM fields)
  3D layer:  Tetryons (regular tetrahedra) — Matter particles
             These are Lorentz INVARIANT (same size/shape always)

  Triangle height = l_q = 1×10⁻¹⁵ m (1 femtometre, Tetryonic gauge)
  Side length = L = (2/√3)×l_q = 1.1547 fm
  4 ZPF quanta → 1 Tetryon:  M₀ = 4m/c²


STEP 1 — INSTALL SDL2 (two options)
-------------------------------------

OPTION A: NuGet (easiest, recommended)
  1. Open Visual Studio
  2. Create new project: Empty C++ Project (x64)
  3. Add main.cpp to the project
  4. Tools → NuGet Package Manager → Manage NuGet Packages
  5. Browse → search "SDL2"  → install "SDL2" by Dominic Mézoni (avio)
  6. Browse → search "SDL2_ttf" → install "sdl2.ttf" 
  7. Skip to STEP 3 (NuGet sets paths automatically)

OPTION B: Manual install
  1. Download SDL2 development libraries (VS):
     https://github.com/libsdl-org/SDL/releases
     → SDL2-devel-2.x.x-VC.zip
  
  2. Download SDL2_ttf:
     https://github.com/libsdl-org/SDL_ttf/releases
     → SDL2_ttf-devel-2.x.x-VC.zip
  
  3. Extract:
     SDL2     → C:\SDL2\       (so C:\SDL2\include\SDL.h exists)
     SDL2_ttf → C:\SDL2_ttf\   (so C:\SDL2_ttf\include\SDL_ttf.h exists)
  
  4. If you put them elsewhere, edit TetryonicsGoL.vcxproj lines:
     <SDL2Dir>C:\SDL2</SDL2Dir>
     <SDL2TTFDir>C:\SDL2_ttf</SDL2TTFDir>


STEP 2 — OPEN SOLUTION
-----------------------
  Double-click TetryonicsGoL.sln
  (Or: File → Open → Project/Solution → select TetryonicsGoL.sln)


STEP 3 — BUILD
--------------
  Build → Build Solution  (Ctrl+Shift+B)
  
  The .exe and required DLLs will be in:
    bin\x64\Debug\TetryonicsGoL.exe
    bin\x64\Debug\SDL2.dll
    bin\x64\Debug\SDL2_ttf.dll
    bin\x64\Debug\libfreetype-6.dll


STEP 4 — RUN
------------
  Debug → Start Without Debugging  (Ctrl+F5)
  Or run the .exe directly from bin\x64\Debug\


CONTROLS
--------
  SPACE       Pause / Resume simulation
  F1          Preset: ZPF vacuum sea (random noise, watch it evolve)
  F2          Preset: KEM field gliders (triangle gliders, Lorentz variant)
  F3          Preset: Photon lattice (neutral pairs, diamond geometry)
  F4          Preset: Tetryon matter (3D particles, Lorentz invariant)
  F5          Preset: Mixed (ZPF + Tetryons + photons interacting)
  F6          Preset: Hexagonal ring (6×60°=360° vacuum closure proof)
  
  1           Draw mode: ZPF+ (positive charge, red/orange)
  2           Draw mode: ZPF- (negative charge, blue)
  3           Draw mode: ZPF0 (neutral/photon pair, cyan)
  4           Draw mode: Place Tetryon (3D matter particle)
  5           Draw mode: Erase
  
  LMB         Draw / place (click or drag to paint)
  RMB+drag    Pan the viewport
  R           Reset viewport to default position
  
  G           Toggle grid lines on/off
  K           Toggle KEM field indicators (yellow circles on Tetryons)
  M           Toggle Tetryon (3D matter) rendering
  C           Clear all cells and particles
  +           Increase simulation speed
  -           Decrease simulation speed
  ESC         Quit


PHYSICS NOTES
-------------
ZPF Game of Life rules (from Tetryonics Section 3 & 5):
  - Each triangle has 3 face-neighbors (strong force range = L)
  - Survive: 2 face-neighbors (stable pairing, like photon = 2 ZPF)
  - Survive weakly: 1 face-neighbor
  - Die: 0 (isolated) or 3 (overcrowded) face-neighbors
  - Birth: 3 alive face-neighbors → new ZPF from vacuum
  - Photon birth: 2 neighbors (one +, one -) → neutral pair

Tetryon formation:
  - When 4 ZPF quanta form a 2-rhombus cluster on the A2 lattice
  - They are consumed and a Tetryon (3D Matter) spawns
  - Implements M₀ = 4m/c² (Section 2.2, 3.4)
  - Tetryon has Lorentz invariant geometry — same shape at all velocities

Tetryon physics:
  - Rest energy: M₀c⁴ (Lorentz invariant — topology unchanged by velocity)
  - KEM field: E_KEM = M₀v² (Lorentz variant — yellow circle shows this)
  - Strong force interaction: attractive for opposite charge,
    repulsive for same, within distance L (Section 5.2)
  - Slow Tetryons decay back into 4 ZPF quanta (vacuum deposition)

Charge encoding:
  - ZPF+: clockwise EM energy flux (Section 5.1) → red/orange
  - ZPF-: counter-clockwise EM flux → blue
  - Neutral/photon: paired + and - (Section 3.2) → cyan

A2 lattice:
  - Gram metric: g_μν = [[1, 1/2],[1/2, 1]]
  - det(g) = 3/4, √det(g) = √3/2
  - Exactly 6 triangles meet at each vertex: 6×60° = 360°
  - Angular defect = 0 → flat spacetime, Ω_k = 0 (Section 4.1, 9.1)
  - This is the A2 Cartan/SU(3) root lattice (Section 8.2)


TROUBLESHOOTING
---------------
"Cannot open SDL.h":
  SDL2 include path not set. Check SDL2Dir in the .vcxproj file.

"Cannot open SDL2.lib":
  SDL2 lib path not set. Check SDL2Dir and make sure x64 libs exist.

"SDL2.dll not found" at runtime:
  DLL copy post-build failed. Manually copy SDL2.dll, SDL2_ttf.dll,
  and libfreetype-6.dll to the same folder as the .exe.

No text in the panel:
  SDL2_ttf font not loading. The app tries common Windows font paths
  (consola.ttf, cour.ttf, arial.ttf). Simulation still runs without fonts.

Slow performance:
  Build in Release mode (much faster). Or reduce gridW/gridH in GameState
  initialization in main().

VS2019 users:
  Change <PlatformToolset>v143</PlatformToolset> to v142 in the .vcxproj.


EXTENDING THE SIMULATION
-------------------------
main.cpp is organized so you can easily extend:

  - loadPreset()     : add more preset patterns
  - stepZPF()        : modify the GoL rules (Tetryonic birth/death conditions)
  - stepTetryons()   : add more Tetryonic physics (weak force, gravity, decay)
  - renderGrid()     : change visual representation
  - faceNeighbors()  : already returns 3 strong-force face neighbors
  - vertexNeighbors(): returns 6 weak-force vertex neighbors (not yet used in rules)

The Gram metric distance (q²+qr+r²) is used for Tetryon-Tetryon interactions
and can be applied to ZPF-Tetryon coupling as a next step.

================================================================================
AUTHORS: James M. Moore, Richard A. Blankenship
THEORY:  Kelvin C. Abraham — Tetryonics (2008–2025)
================================================================================
